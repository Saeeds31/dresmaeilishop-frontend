import{c as s}from"./D0v5ax5v.js";const c=s("minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{c as M};
