import{I as s}from"./Di7MzSpi.js";const p=s("/images/logo.png");export{p as _};
