import{I as s}from"./CbgKMwAW.js";const p=s("/images/logo.png");export{p as _};
